export interface TimeItem {
  name: string;
  repsCount: number;
  weight?: number;
  time: string;
  isBreak?: boolean;
  breakTime: number;
}
