import { Component } from '@angular/core';

@Component({
  selector: 'app-home-panel',
  imports: [],
  templateUrl: './home-panel.html',
  styleUrl: './home-panel.scss'
})
export class HomePanel {

}
